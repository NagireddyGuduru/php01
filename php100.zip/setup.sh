#!/bin/bash
touch /tmp/a.txt /tmp/b.txt /tmp/c.txt
sudo yum -y install perl-DateTime perl-Sys-Syslog perl-LWP-Protocol-https
sudo yum -y install perl-Switch perl-URI perl-Bundle-LWP 
sudo yum -y install perl-core
